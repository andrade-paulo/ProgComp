#include <iostream>
#include <cstdlib>
using namespace std;

int main() {
	srand(4343);

	cout << rand() << " ";
	cout << rand() << " ";
	cout << rand() << " ";
	cout << rand() << " ";
	cout << rand();
}