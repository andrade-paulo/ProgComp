#include <iostream>
using namespace std;

int main() {
	float n1, n2;
	
	cout << "Digite um valor inteiro: ";
	cin >> n1;
	cout << "Digite outro valor inteiro: ";
	cin >> n2;

	cout << "Media = " << (n1 + n2) / 2;
}