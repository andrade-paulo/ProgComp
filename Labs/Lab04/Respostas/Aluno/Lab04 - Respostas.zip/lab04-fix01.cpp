#include <iostream>
using namespace std;

void sorria();

int main() {
	sorria(); sorria(); sorria(); sorria();
	cout << endl;
	sorria(); sorria();
	cout << endl;
	sorria();
}

void sorria() {
	cout << "Sorria! ";
}