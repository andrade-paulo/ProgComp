#include <iostream>
using namespace std;

int main() {
	system("chcp 1252 > nul"); // Exibir acentos

	cout << "Paulo Andrade" << endl;
	cout << "Paulo" << endl << "Andrade" << endl;
	cout << "Paulo ";
	cout << "Andrade";
}