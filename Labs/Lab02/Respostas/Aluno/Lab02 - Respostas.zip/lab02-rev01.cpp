#include <iostream>
using namespace std;

int main() {
	// Vers�o com endl
	cout << "Bem-vindo" << endl << "ao mundo" << endl << "do C++" << endl;
	cout << endl;

	// Vers�o com \n
	cout << "Bem-vindo \n" << "ao mundo \n" << "do C++";
}