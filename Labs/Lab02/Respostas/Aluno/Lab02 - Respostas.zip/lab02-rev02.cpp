#include <iostream>
using namespace std;

int main() {
	// -=-=- Texto separado -=-=-

	// Vers�o com endl
	cout << "Bem-vindo" << endl;
	cout << "ao mundo" << endl;
	cout << "do C++" << endl;
	cout << endl;

	// Vers�o com \n
	cout << "Bem-vindo \n";
	cout << "ao mundo \n";
	cout << "do C++ \n";
	cout << "\n";

	// -=-=- Texto junto -=-=-

	cout << "Bem-vindo ";
	cout << "ao mundo ";
	cout << "do C++";
}