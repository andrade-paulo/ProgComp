#include <iostream>
using namespace std;

int main(int argc, char ** argv) {
	cout << argv[1] << " " << argv[2] << " programar" << endl;
}