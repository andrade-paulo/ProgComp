#include <iostream>
using namespace std;

int main()
{
	int vet[11] {};

	for (int i = 0; i <= 20; i++) {
		vet[i] = 60;
		cout << i << " ";
	}
	
	return 0;
}
