#include <iostream>
using namespace std;

int main()
{
	double x1;
	double x2;
	int x3;

	cout << "Digite um valor: ";
	cin >> x1;

	cout << "Digite um valor: ";
	cin >> x2;

	x3 = x1 + x2;

	cout << "A adicao inteira dos valores e: " << x3 << endl;

	return 0;
}