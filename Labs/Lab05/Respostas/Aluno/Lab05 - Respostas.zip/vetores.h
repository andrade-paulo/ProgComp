float angulo(float, float);

float modulo(float, float);

