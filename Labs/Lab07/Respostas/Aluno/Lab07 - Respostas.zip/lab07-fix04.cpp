#include <iostream>
using namespace std;

int main() {
	cout << "Ma�a =\t\t20 unidades\n";
	cout << "Melancia =\t20 unidades\n";
	cout << "Ameixa =  \t20 unidades\n";
}