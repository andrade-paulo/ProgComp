#include <iostream>
using namespace std;

int main() {
	float alt, larg, comp;

	cin >> alt >> larg >> comp;
	cout << "O volume do cubo vale " << alt * larg * comp << "cm cubicos";
}