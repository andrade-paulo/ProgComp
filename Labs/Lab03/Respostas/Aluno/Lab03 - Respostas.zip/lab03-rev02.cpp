#include <iostream>
using namespace std;

int main() {
	int hora, minuto;
	char sep;

	cin >> hora >> sep >> minuto;
	cout << hora << " horas e " << minuto << " minutos";
}