#include <iostream>
using namespace std;

int main() {
	int medida;
	medida = 10;

	cout << "Medida: " << medida << endl
		<< "2x medida: " << medida * 2 << endl
		<< "Medida ao quadrado: " << pow(medida, 2);
}
