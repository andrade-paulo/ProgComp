#include <iostream>
using namespace std;

int main() {
	int num;
	cout << "Digite um numero de 0 a 9: ";
	cin >> num;

	cout << num << " x 0 = " << num * 0 << endl;
	cout << num << " x 1 = " << num * 1 << endl;
	cout << num << " x 2 = " << num * 2 << endl;
	cout << num << " x 3 = " << num * 3 << endl;
	cout << num << " x 4 = " << num * 4 << endl;
	cout << num << " x 5 = " << num * 5 << endl;
	cout << num << " x 6 = " << num * 6 << endl;
	cout << num << " x 7 = " << num * 7 << endl;
	cout << num << " x 8 = " << num * 8 << endl;
	cout << num << " x 9 = " << num * 9 << endl;
}
