#include <iostream>
using namespace std;

int main()
{
	char vetor[] = "Pratique Muito";
	
	for (int i = 0; vetor[i]; i++)
		cout << vetor[i];
	
	return 0;
}