#include <iostream>
using namespace std;

#define ZERO 0

int main() {
	system("chcp 1252 > nul");

	int total = 0;
	cout << "Inicialmente total = " << total << " (ZERO)\n";
	total = 50;
	cout << "Depois da \"atribui��o\" total = " << total << endl;
	
	return ZERO;
}