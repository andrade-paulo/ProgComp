#include <iostream>
using namespace std;

int main()
{
	float peso;
	
	peso = 30;
	cout << peso;
	
	// delete peso;

	return 0;
}