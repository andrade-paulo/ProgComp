#include <iostream>
using namespace std;

int main()
{
	char teste_vetor[] = {'t', 'e', 's', 't', 'e', '0'};
	char teste_string[] = {'t', 'e', 's', 't', 'e', '1', '\0'};

	cout << teste_vetor << endl << teste_string << endl;

	return 0;
}