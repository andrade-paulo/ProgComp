#include <iostream>
#include <string>
using namespace std;

int main()
{
	char nome[] = "C++ Primer Plus";

	cout << nome << endl << "strlen: " << strlen(nome) << endl << "sizeof: " << sizeof(nome) << endl;

	return 0;
}