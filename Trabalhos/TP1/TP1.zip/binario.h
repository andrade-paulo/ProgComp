#pragma once

unsigned short ligar_bit(unsigned short, int);

unsigned short desligar_bit(unsigned short, int);

bool testar_bit(unsigned short, int);

unsigned short and_binario(unsigned short, unsigned short);

unsigned short or_binario(unsigned short, unsigned short);

unsigned short bits_baixos(unsigned short);

unsigned short bits_altos(unsigned short);