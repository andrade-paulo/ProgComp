#pragma once

bool avaliar(unsigned short valor);

unsigned short cruzamento_ponto_unico(unsigned short, unsigned short);

unsigned short cruzamento_aritmetico(unsigned short, unsigned short);

unsigned short mutacao_simples(unsigned short);

unsigned short mutacao_dupla(unsigned short);